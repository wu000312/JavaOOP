package com.algonquin.cst8288.assignment1.controller;


import java.io.IOException;

/**
 * 
 * Main class to execute the application
 * 
 */

public class Main {
	
	
	public static void main(String[] args) throws IOException {
		

		// Instantiate two Employee objects and use PermanentEmployeeService.java 
		// and ContractEmployeeService.java to calculate and populate required data for objects
		// Utilize EmployeeController.java to save both objects in JSON and Text formats, 
		// saving the data in files named json_employee_data.txt and text_employee_data.txt.
		// Do the same thing to output the data to the console instead of saving it to a file.
		
	}	

}
