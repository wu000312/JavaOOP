package com.algonquin.cst8288.assignment1.controller;

import java.io.IOException;
import com.algonquin.cst8288.assignment1.emoloyee.Employee;

/**
 * Process, validate, and save employee data.
 */
public class EmployeeController {

    private final EmployeeValidator employeeValidator;
    private final PersistenceService jsonPersistenceService;
    private final PersistenceService textPersistenceService;

    public EmployeeController(EmployeeValidator employeeValidator,
                              PersistenceService jsonPersistenceService,
                              PersistenceService textPersistenceService) {
        this.employeeValidator = employeeValidator;
        this.jsonPersistenceService = jsonPersistenceService;
        this.textPersistenceService = textPersistenceService;
    }

    public String processEmployee(Employee employee) throws IOException {
        // Validate data
        if (!employeeValidator.isValidEmployee(employee)) {
            return "FAILED";
        }
            return "SUCCESS";
    }

    public void saveEmployee(Employee employee, String jsonFilename, String textFilename) throws IOException {
        // Save data in JSON format
        jsonPersistenceService.saveEmployee(employee, jsonFilename);
        System.out.println("Saving employee data to file: " + jsonFilename);

        // Save data in Text format
        textPersistenceService.saveEmployee(employee, textFilename);
        System.out.println("Saving employee data to file: " + textFilename);
    }
}
