package com.algonquin.cst8288.assignment1.emoloyee;
/**
 * Permanent Employee interface(bonus+pension)
 */
public interface PermanentEmployeeIn extends EmployeeService{
	
	double pensionContribution(Employee employee);
	double calculateBonus(Employee employee);
	
   
    
}
