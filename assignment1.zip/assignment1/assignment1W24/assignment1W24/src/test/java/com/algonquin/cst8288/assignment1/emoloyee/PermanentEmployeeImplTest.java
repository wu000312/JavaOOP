package com.algonquin.cst8288.assignment1.emoloyee;

import static org.junit.Assert.*;

import org.junit.Test;

public class PermanentEmployeeImplTest {

	@Test
	public void testCalculateTotalCompensation() {
        // Create an instance of PermanentEmployeeImpl
        PermanentEmployeeImpl permanentEmployee = new PermanentEmployeeImpl();

        // Create a sample Employee with a salary and years of service
        Employee employee = new Employee();
        employee.setSalary(100000.0);
        employee.setNumberOfServiceYear(3);

        // expected total compensation(calculated by myself)
        double expectedTotalCompensation = 1075435230;

        // Get the actual total compensation from the method--from PermanentEmployeeImp.java
        double actualTotalCompensation = permanentEmployee.calculateTotalCompensation(employee);

        // Assert that the actual total compensation matches the expected value
        assertEquals(expectedTotalCompensation, actualTotalCompensation, 0.01);
    }

}
