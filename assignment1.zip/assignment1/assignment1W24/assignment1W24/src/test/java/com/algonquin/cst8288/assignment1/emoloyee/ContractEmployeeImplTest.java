package com.algonquin.cst8288.assignment1.emoloyee;

import java.util.Calendar;
import java.util.Date;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class ContractEmployeeImplTest {

    @Test
    public void testRenewalDate() {
       
        ContractEmployeeImpl contractEmployee = new ContractEmployeeImpl();

     
        Calendar expectedRenewalDate = Calendar.getInstance();
        expectedRenewalDate.set(2025, Calendar.JANUARY, 25); // Assuming today is join date, so 2025/1/24 is renewal date

        // Get the actual renewal date from the method
        Date actualRenewalDate = contractEmployee.renewalDate();

        // Assert that the actual renewal date is close to the expected renewal date
        long timeDifference = Math.abs(expectedRenewalDate.getTimeInMillis() - actualRenewalDate.getTime());
        assertTrue("Renewal date is wrong", timeDifference <= 1000);
    }
}
