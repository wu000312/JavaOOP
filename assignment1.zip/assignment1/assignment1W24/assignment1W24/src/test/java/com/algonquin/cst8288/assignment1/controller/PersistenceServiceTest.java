package com.algonquin.cst8288.assignment1.controller;

import static org.junit.Assert.*;
import com.algonquin.cst8288.assignment1.persistence.*;
import com.algonquin.cst8288.assignment1.emoloyee.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.junit.Test;

public class PersistenceServiceTest {

    @Test
    public void testSaveEmployee() throws IOException {
        
        Formatter formatter = new TextFormatter();

        
        PersistenceService persistenceService = new PersistenceService(formatter);

        // Create a sample Employee
        Employee employee = new Employee();
        employee.setName("javahater");
        employee.setEmail("javaAplus@example.com");
        // Set other employee properties as needed

        // Define the expected filename
        String filename = "test_employee_data.txt";

        // Call the saveEmployee method
        persistenceService.saveEmployee(employee, filename);

        // Read the content of the file
        Path filePath = Paths.get(filename);
        String fileContent = new String(Files.readAllBytes(filePath));

        // Assert that the file content contains the expected data
        assertTrue(fileContent.contains("javahater"));
        assertTrue(fileContent.contains("jasdasd@example.com"));
        // clean up the created file after the test
        Files.delete(filePath);
    }

}
