package com.algonquin.cst8288.assignment1.persistence;

import java.io.IOException;

import com.algonquin.cst8288.assignment1.emoloyee.Employee;

/**
 * An implementation for formatting the data in text (key-value pairs) format.
 */
public class TextFormatter implements Formatter {

    /**
     * The method processes the employee object and formats the data as key-value pairs.
     */
    @Override
    public String format(Employee employee) throws IOException {
        StringBuilder formattedData = new StringBuilder();

        formattedData.append("name=").append(employee.getName()).append(", ");
        formattedData.append("email=").append(employee.getEmail()).append(", ");
        formattedData.append("address=").append(employee.getAddress()).append(", ");
        formattedData.append("salary=").append(employee.getSalary()).append(", ");
        formattedData.append("numberOfServiceYear=").append(employee.getNumberOfServiceYear()).append(", ");
        formattedData.append("bonus=").append(employee.getBonus()).append(", ");
        formattedData.append("totalCompensation=").append(employee.getTotalCompensation()).append(", ");
        formattedData.append("renewalDate=").append(employee.getRenewalDate());

        return formattedData.toString();
    }
}
