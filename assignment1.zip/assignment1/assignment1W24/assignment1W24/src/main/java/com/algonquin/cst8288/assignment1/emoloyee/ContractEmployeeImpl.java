package com.algonquin.cst8288.assignment1.emoloyee;

import java.util.Calendar;
import java.util.Date;

public class ContractEmployeeImpl implements ContractEmployeeIn {
	@Override
    public double calculateTotalCompensation(Employee employee) {
        return employee.getSalary(); 
    }

	@Override
	public Date renewalDate() {
		 // Renewal date is calculated 1 year from today
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.YEAR, 1);
        return calendar.getTime();
	
	}
}
