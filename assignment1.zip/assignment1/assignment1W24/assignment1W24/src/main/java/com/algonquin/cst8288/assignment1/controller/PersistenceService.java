package com.algonquin.cst8288.assignment1.controller;
/**
 * 
 * 
 * @param employee
 * @throws IOException
 * Write data into file but it violates DIP
 * 
 */
import com.algonquin.cst8288.assignment1.persistence.Formatter;
import com.algonquin.cst8288.assignment1.emoloyee.Employee;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class PersistenceService {
	    //violates the Dependency Inversion Principle 
	    //directly creates an instance of the JSONFormatter class within the method. 
	 	//high-level module (EmployeeController) - low-level module (JSONFormatter)
	 private final Formatter formatter;

	    public PersistenceService(Formatter formatter) {
	        this.formatter = formatter;
	    }

	    public void saveEmployee(Employee employee, String filename) throws IOException {
	        try (PrintWriter writer = new PrintWriter(new FileWriter(filename, true))) {//Here true: avoid overwriting!!
	            writer.println(formatter.format(employee));
	            writer.flush();
	        }
	    }
}
