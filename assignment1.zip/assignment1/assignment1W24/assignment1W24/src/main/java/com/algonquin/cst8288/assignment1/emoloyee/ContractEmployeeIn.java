package com.algonquin.cst8288.assignment1.emoloyee;
/**
 * Contract Employee interface(date)
 */
import java.util.Date;

public interface ContractEmployeeIn extends EmployeeService {
	Date renewalDate();
}
