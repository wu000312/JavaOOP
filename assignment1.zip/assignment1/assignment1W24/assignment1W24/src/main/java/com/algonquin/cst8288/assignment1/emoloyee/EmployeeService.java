package com.algonquin.cst8288.assignment1.emoloyee;



/**
 * 
 * EmployeeService interface
 * Modified into base interface, two interfaces have been created:P & C
 * 
 */
//Interface Segregation Principle

public interface EmployeeService {

	public double calculateTotalCompensation(Employee employee);
	

	
}
