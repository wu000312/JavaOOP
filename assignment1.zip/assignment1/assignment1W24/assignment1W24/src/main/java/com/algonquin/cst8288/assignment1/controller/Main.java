package com.algonquin.cst8288.assignment1.controller;

import com.algonquin.cst8288.assignment1.emoloyee.*;
import com.algonquin.cst8288.assignment1.persistence.JSONFormatter;
import com.algonquin.cst8288.assignment1.persistence.TextFormatter;
import java.io.IOException;

/**
 * @author Yanan Wu
 * @since 2024.1.24
 * Main class to execute the application
 */
public class Main {

    public static void main(String[] args) throws IOException {

        // Instantiate two Employee objects and use PermanentEmployeeService.java
        // 1st employee, permanent
        Employee permanentEmployee = new Employee();
        
        
        
        permanentEmployee.setName("YananWu");
        permanentEmployee.setEmail("wu000312@algonquinlive.com");
        permanentEmployee.setSalary(88888);
        permanentEmployee.setAddress("Ottawa,Ontario,Canada");
        permanentEmployee.setNumberOfServiceYear(2);
        PermanentEmployeeImpl permanentEmployeeImpl = new PermanentEmployeeImpl();
        permanentEmployee.setBonus(permanentEmployeeImpl.calculateBonus(permanentEmployee));
       
        // and ContractEmployeeService.java
        // 2nd employee, contract
        Employee contractEmployee = new Employee();
        contractEmployee.setName("FiveWU");
        contractEmployee.setEmail("littleanimal5@gmail.com");
        contractEmployee.setSalary(100000);
        contractEmployee.setAddress("Ottawa");
        contractEmployee.setNumberOfServiceYear(5);
        contractEmployee.setBonus(0);

        // to calculate and populate required data for objects
        // 1st
        PermanentEmployeeImpl permanentEmployeeService = new PermanentEmployeeImpl();
        permanentEmployee.setTotalCompensation(permanentEmployeeService.calculateTotalCompensation(permanentEmployee)); // Set the calculated total compensation
        
        
        // 2nd
        ContractEmployeeImpl contractEmployeeService = new ContractEmployeeImpl();
        contractEmployee.setTotalCompensation(contractEmployeeService.calculateTotalCompensation(contractEmployee));
        contractEmployee.setRenewalDate(contractEmployeeService.renewalDate());
        

        
        // saving the data in files named json_employee_data.txt and text_employee_data.txt.
        EmployeeController employeeController = new EmployeeController(new EmployeeValidator(),
                new PersistenceService(new JSONFormatter()),
                new PersistenceService(new TextFormatter()));

        String result1 = employeeController.processEmployee(permanentEmployee);
        System.out.println("Processing Permanent Employee: " + result1);

        String result2 = employeeController.processEmployee(contractEmployee);
        System.out.println("Processing Contract Employee: " + result2);

        // Do the same thing to output the data to the console instead of saving it to a file.
        System.out.println("Employee1:");
        employeeController.saveEmployee(permanentEmployee, "json_employee_data.txt", "text_employee_data.txt");
        System.out.println(new TextFormatter().format(permanentEmployee));
        System.out.println();
        System.out.println();
        System.out.println("Employee2:");
        employeeController.saveEmployee(contractEmployee, "json_employee_data.txt", "text_employee_data.txt");
        System.out.println(new TextFormatter().format(contractEmployee));
    }
}
